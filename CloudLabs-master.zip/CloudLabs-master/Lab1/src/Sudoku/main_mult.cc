#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <pthread.h>
#include "sudoku.h"
#include<stdlib.h>

typedef struct {
   int first;
   int last;
   int** tqa;//用于存储问题和结果数组
}threadtask;
 
void* threadfun(void* args){//线程函数
   threadtask* task = (threadtask*) args;
   int first=task->first;
   int last=task->last;
   int** tqa=task->tqa;
   int i=0;
 
   for(i=first;i<last;i++){
      solve_sudoku_dancing_links(tqa[i]);
   }
   pthread_exit(NULL);
   return NULL;
}
 
int main(int argc, char* argv[])
{
   char testfile[128]= "\0";
   while(scanf("%s",testfile)){//文件路径输入
       char puzzle[128];
 
       FILE* file1 = fopen(testfile, "r");
       int testn=0;//测试题目数量
       while (fgets(puzzle, sizeof puzzle, file1) != NULL) {
           testn++;
       }
       fclose(file1);
 
       int threadn=6;//线程数为6个
 
       int i=0;
       int row=testn, col=N;
    
       int **testqa = (int**)malloc(sizeof(int*) * row); 
       for (i=0;i<row;i++)
       {
           testqa[i] = (int*)malloc(sizeof(int) * col);//结果数组
       }
 
       FILE* file2 = fopen(testfile, "r");
       i=0;
       char temp[testn][128];//临时数组
       while (fgets(temp[i], sizeof temp[i], file2) != NULL) {
           i++;
       }
 
       //输入转换
       for(int j=0;j<testn;j++){
           for (int k = 0; k < N; k++) {
               testqa[j][k] = (int)(temp[j][k] - '0');
           }
       }
 
       int pertask= testn/threadn;
       threadtask threadgroup[threadn];
       pthread_t th[threadn]; 
 
       if(pertask>=1){//为每个线程分配任务
          for(i=0;i<threadn;i++)
          {
            int first=(int)pertask*i;//平均分配任务
            int last;
            if(i!=threadn-1)
                last=(int)pertask*(i+1);
            else
                last=testn;
 
            threadgroup[i].first=first;
            threadgroup[i].last=last;
            threadgroup[i].tqa=testqa;
 
            if(pthread_create(&th[i], NULL, threadfun, &threadgroup[i])!=0){//创建线程
                perror("pthread_create failed");
                exit(1);
            }
         } 
 
         for(i=0;i<threadn;i++)
         pthread_join(th[i], NULL);
       }
       else{//一个线程的情况
           threadgroup[0].first=0;
           threadgroup[0].last=testn;
           threadgroup[0].tqa=testqa;
           if(pthread_create(&th[0], NULL, threadfun, &threadgroup[0])!=0){
               perror("pthread_create failed");
               exit(1);
           }
           pthread_join(th[0], NULL);
       }
 
       int x=0;
       int y=0;
       //结果输出
       for(x=0;x<testn;x++){
           for(y=0;y<N;y++){
               printf("%d",testqa[x][y]);
           }
           printf("\n");
       }
  
       free(testqa);
       fflush(stdout);
   }
   return 0;
}
